// Ask for confirmation before destructive actions (forms with data-confirm).
document.querySelectorAll("form[data-confirm]").forEach(function (form) {
  form.addEventListener("submit", function (e) {
    if (!confirm(form.dataset.confirm)) e.preventDefault();
  });
});
// Dates cannot be in the future; end date cannot be before start date.
var today = new Date().toISOString().split("T")[0];
document.querySelectorAll("input[type=date]").forEach(function (i) { i.max = today; });
var s = document.getElementById("start_date"), en = document.getElementById("end_date");
if (s && en) s.addEventListener("change", function () { en.min = s.value; });

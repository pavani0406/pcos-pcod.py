"""Transparent, rule-based Early-Risk Indicator Score (0-100).

NOT a clinically validated model and NOT a diagnosis. To upgrade later, replace
calculate_risk() with an ML model that returns the same dictionary shape:
    {"score": int, "category": str, "level": str, "factors": [...], "cycle_data_used": bool}
"""

ANSWER_VALUE = {"yes": 1.0, "sometimes": 0.5, "no": 0.0}

# key: (maximum points, label). All maximums (including the two cycle rules) add up to 100.
QUESTION_FACTORS = {
    "irregular_periods": (12, "Irregular periods (reported)"),
    "long_cycles":       (10, "Very long cycles (reported)"),
    "heavy_bleeding":    (4,  "Unusually heavy bleeding"),
    "acne":              (8,  "Acne"),
    "excess_hair":       (14, "Excess facial/body hair"),
    "hair_thinning":     (8,  "Hair thinning"),
    "dark_skin":         (10, "Darkened skin patches"),
    "weight_change":     (4,  "Unexplained weight change"),
    "family_history":    (8,  "Family history of PCOS"),
}
TRACKED_IRREGULAR_MAX = 12   # share of tracked cycles outside 21-35 days
TRACKED_VARIABILITY_MAX = 10  # spread between shortest and longest tracked cycle


def _factor(key, label, points, maximum, detail=""):
    points = round(points, 1)
    return {"key": key, "label": label, "points": points, "max": maximum,
            "percent": round(points / maximum * 100), "contributed": points > 0, "detail": detail}


def _category(score):
    if score >= 55:
        return "Higher early-risk indicators", "higher"
    if score >= 30:
        return "Moderate early-risk indicators", "moderate"
    return "Low early-risk indicators", "low"


def calculate_risk(data):
    """data: questionnaire answers ('yes'/'sometimes'/'no') + 'cycle_lengths' (list of ints)."""
    factors = []
    for key, (maximum, label) in QUESTION_FACTORS.items():
        answer = data.get(key, "no")
        factors.append(_factor(key, label, maximum * ANSWER_VALUE.get(answer, 0), maximum,
                               f"You answered: {answer}"))

    lengths = data.get("cycle_lengths") or []
    cycle_used = len(lengths) >= 2  # need 3+ recorded periods to judge variation
    if cycle_used:
        outside = [n for n in lengths if n < 21 or n > 35]
        pts = TRACKED_IRREGULAR_MAX * len(outside) / len(lengths)
        factors.append(_factor("tracked_irregular", "Tracked cycles outside 21-35 days", pts,
                               TRACKED_IRREGULAR_MAX, f"{len(outside)} of {len(lengths)} cycles outside range"))
        spread = max(lengths) - min(lengths)
        pts = TRACKED_VARIABILITY_MAX if spread > 7 else TRACKED_VARIABILITY_MAX / 2 if spread > 4 else 0
        factors.append(_factor("tracked_variability", "Cycle length variation", pts,
                               TRACKED_VARIABILITY_MAX, f"Shortest to longest differ by {spread} days"))

    available = sum(f["max"] for f in factors)  # only score what we could actually measure
    score = round(sum(f["points"] for f in factors) / available * 100)
    category, level = _category(score)
    return {"score": score, "category": category, "level": level,
            "factors": factors, "cycle_data_used": cycle_used}

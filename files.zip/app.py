"""AI Smart Menstrual & PCOS Early-Risk Recognition System - Flask prototype.
Screening/education only. Not a diagnosis tool."""
import io
import json
import os
import re
import sqlite3
from datetime import date, datetime, timedelta
from functools import wraps
from xml.sax.saxutils import escape

from flask import (Flask, flash, g, redirect, render_template, request,
                   send_file, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from utils.risk_score import calculate_risk

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")

DISCLAIMER = ("This application is for early-risk screening and educational purposes only. "
              "It does not diagnose PCOS. Please consult a qualified healthcare professional "
              "for diagnosis and treatment.")
REPORT_DISCLAIMER = ("This report is an informational screening summary and is not a medical diagnosis. "
                     "A qualified healthcare professional should interpret these findings.")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-secret-change-me")  # set SECRET_KEY in real use

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

QUESTIONS = [
    ("irregular_periods", "Menstrual symptoms", "Are your periods frequently irregular?"),
    ("long_cycles", "Menstrual symptoms", "Do you frequently have very long cycles?"),
    ("heavy_bleeding", "Menstrual symptoms", "Do you experience unusually heavy bleeding?"),
    ("acne", "Hormonal / skin-related symptoms", "Do you have acne?"),
    ("excess_hair", "Hormonal / skin-related symptoms", "Do you have excess facial or body hair?"),
    ("hair_thinning", "Hormonal / skin-related symptoms", "Do you have hair thinning?"),
    ("dark_skin", "Hormonal / skin-related symptoms", "Do you have darkened skin patches?"),
    ("weight_change", "Other information", "Have you had recent unexplained weight changes?"),
    ("family_history", "Other information", "Is there a family history of PCOS?"),
]
SYMPTOM_TEXT = {k: t for k, _, t in QUESTIONS}
VALID_ANSWERS = ("yes", "no", "sometimes")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
    age INTEGER NOT NULL, consent_given INTEGER NOT NULL DEFAULT 0, consent_timestamp TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS menstrual_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    start_date TEXT NOT NULL, end_date TEXT NOT NULL,
    flow TEXT NOT NULL CHECK (flow IN ('Light','Medium','Heavy')), notes TEXT);
CREATE TABLE IF NOT EXISTS symptoms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    irregular_periods TEXT, long_cycles TEXT, heavy_bleeding TEXT, acne TEXT, excess_hair TEXT,
    hair_thinning TEXT, dark_skin TEXT, weight_change TEXT, family_history TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL, category TEXT NOT NULL, contributing_factors TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
"""


# ---------- database helpers ----------
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.executescript(SCHEMA)


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


# ---------- auth decorators ----------
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        uid = session.get("user_id")
        user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone() if uid else None
        if user is None:
            session.clear()
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        g.user = user
        return view(*args, **kwargs)
    return wrapped


def consent_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not g.user["consent_given"]:
            flash("Please give consent before using the health features.", "warning")
            return redirect(url_for("consent"))
        return view(*args, **kwargs)
    return login_required(wrapped)


@app.context_processor
def inject_globals():
    return {"user": g.get("user"), "DISCLAIMER": DISCLAIMER, "REPORT_DISCLAIMER": REPORT_DISCLAIMER}


# ---------- analysis helpers ----------
def fetch_records(uid):
    return get_db().execute("SELECT * FROM menstrual_records WHERE user_id = ? ORDER BY start_date ASC",
                            (uid,)).fetchall()


def analyze_cycles(records):
    """Rule-based cycle analysis. Cycle length = this start date - previous start date."""
    starts = [date.fromisoformat(r["start_date"]) for r in records]
    lengths = [(b - a).days for a, b in zip(starts, starts[1:])]
    a = {"count": len(records), "lengths": lengths,
         "avg": round(sum(lengths) / len(lengths), 1) if lengths else None,
         "short": [n for n in lengths if n < 21], "long": [n for n in lengths if n > 35],
         "variability": len(lengths) >= 2 and max(lengths) - min(lengths) > 7,
         "last_period": starts[-1] if starts else None, "days_since": None, "delayed": False, "messages": []}
    if starts:
        a["days_since"] = (date.today() - starts[-1]).days
        a["delayed"] = a["days_since"] > 45
    m = a["messages"]
    if len(records) < 3:
        m.append("Add at least 3 periods so cycle lengths can be compared.")
    if a["short"]:
        m.append(f"{len(a['short'])} cycle(s) were shorter than 21 days (potentially short cycles).")
    if a["long"]:
        m.append(f"{len(a['long'])} cycle(s) were longer than 35 days (potentially long cycles).")
    if a["variability"]:
        m.append("Your recent cycles show some variation. This can happen for many reasons "
                 "and does not by itself confirm PCOS.")
    if a["delayed"]:
        m.append(f"It has been {a['days_since']} days since your last recorded period start "
                 "(possible missed or delayed period).")
    if len(records) >= 3 and not (a["short"] or a["long"] or a["variability"] or a["delayed"]):
        m.append("Your recorded cycles are within the commonly used 21-35 day range with little variation.")
    return a


def build_rows(records):
    rows, prev = [], None
    for r in records:
        s = date.fromisoformat(r["start_date"])
        n = (s - prev).days if prev else None
        prev = s
        flag = None if n is None else "short" if n < 21 else "long" if n > 35 else "normal"
        rows.append({**dict(r), "cycle_length": n, "flag": flag})
    return list(reversed(rows))


def latest(table, uid):
    return get_db().execute(f"SELECT * FROM {table} WHERE user_id = ? ORDER BY id DESC LIMIT 1",
                            (uid,)).fetchone()


def run_assessment(uid):
    """Combine questionnaire + tracked cycles, score them, and store the result."""
    sym = latest("symptoms", uid)
    if sym is None:
        return False
    data = {k: sym[k] for k in SYMPTOM_TEXT}
    data["cycle_lengths"] = analyze_cycles(fetch_records(uid))["lengths"]
    risk = calculate_risk(data)  # <- swap this call for an ML model later
    db = get_db()
    db.execute("INSERT INTO assessments (user_id, score, category, contributing_factors) VALUES (?,?,?,?)",
               (uid, risk["score"], risk["category"], json.dumps(risk["factors"])))
    db.commit()
    return True


def report_data(uid):
    a = latest("assessments", uid)
    sym = latest("symptoms", uid)
    if a is None:
        return None
    factors = json.loads(a["contributing_factors"])
    selected = [(SYMPTOM_TEXT[k], sym[k]) for k in SYMPTOM_TEXT if sym[k] in ("yes", "sometimes")]
    return {"assessment": a, "cycles": analyze_cycles(fetch_records(uid)),
            "on": [f for f in factors if f["contributed"]], "off": [f for f in factors if not f["contributed"]],
            "selected": selected, "date": a["created_at"][:10]}


# ---------- auth routes ----------
@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        try:
            age = int(request.form.get("age", ""))
        except ValueError:
            age = None
        errors = []
        if not name: errors.append("Full name is required.")
        if not EMAIL_RE.match(email): errors.append("Please enter a valid email address.")
        if len(password) < 8: errors.append("Password must be at least 8 characters.")
        if age is None or not 10 <= age <= 100: errors.append("Please enter a reasonable age (10-100).")
        db = get_db()
        if not errors and db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            errors.append("That email is already registered.")
        if errors:
            for e in errors: flash(e, "danger")
            return render_template("register.html", form=request.form)
        cur = db.execute("INSERT INTO users (name, email, password_hash, age) VALUES (?,?,?,?)",
                         (name, email, generate_password_hash(password), age))
        db.commit()
        session.clear()
        session["user_id"] = cur.lastrowid
        return redirect(url_for("consent"))
    return render_template("register.html", form={})


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        row = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if row and check_password_hash(row["password_hash"], request.form.get("password", "")):
            session.clear()
            session["user_id"] = row["id"]
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/consent", methods=["GET", "POST"])
@login_required
def consent():
    if request.method == "POST":
        if request.form.get("consent") == "on":
            db = get_db()
            db.execute("UPDATE users SET consent_given = 1, consent_timestamp = ? WHERE id = ?",
                       (datetime.now().isoformat(timespec="seconds"), g.user["id"]))
            db.commit()
            return redirect(url_for("dashboard"))
        flash("You must tick the consent box to continue.", "danger")
    return render_template("consent.html")


# ---------- main pages ----------
@app.route("/dashboard")
@consent_required
def dashboard():
    uid = g.user["id"]
    a = analyze_cycles(fetch_records(uid))
    return render_template("dashboard.html", cycles=a, assessment=latest("assessments", uid))


@app.route("/calendar")
@consent_required
def calendar():
    records = fetch_records(g.user["id"])
    return render_template("calendar.html", rows=build_rows(records), cycles=analyze_cycles(records))


@app.route("/add-period", methods=["POST"])
@consent_required
def add_period():
    flow = request.form.get("flow", "")
    notes = request.form.get("notes", "").strip()[:300]
    try:
        start = date.fromisoformat(request.form.get("start_date", ""))
        end = date.fromisoformat(request.form.get("end_date", ""))
    except ValueError:
        flash("Please enter valid start and end dates.", "danger")
        return redirect(url_for("calendar"))
    db = get_db()
    if start > date.today() or end > date.today():
        flash("Dates cannot be in the future.", "danger")
    elif end < start:
        flash("End date cannot be before the start date.", "danger")
    elif (end - start).days > 14:
        flash("A period longer than 15 days looks like a typing mistake - please check the dates.", "danger")
    elif flow not in ("Light", "Medium", "Heavy"):
        flash("Please choose a flow level.", "danger")
    elif db.execute("SELECT 1 FROM menstrual_records WHERE user_id=? AND start_date=?",
                    (g.user["id"], start.isoformat())).fetchone():
        flash("You already recorded a period starting on that date.", "danger")
    else:
        db.execute("INSERT INTO menstrual_records (user_id,start_date,end_date,flow,notes) VALUES (?,?,?,?,?)",
                   (g.user["id"], start.isoformat(), end.isoformat(), flow, notes))
        db.commit()
        flash("Period saved.", "success")
    return redirect(url_for("calendar"))


@app.route("/load-sample", methods=["POST"])
@consent_required
def load_sample():
    """Demo helper: adds 6 periods with cycle lengths 27, 42, 24, 48, 38 days."""
    starts = [date.today() - timedelta(days=25)]
    for gap in (38, 48, 24, 42, 27):
        starts.append(starts[-1] - timedelta(days=gap))
    db, flows = get_db(), ["Medium", "Heavy", "Light"]
    for i, s in enumerate(sorted(starts)):
        if not db.execute("SELECT 1 FROM menstrual_records WHERE user_id=? AND start_date=?",
                          (g.user["id"], s.isoformat())).fetchone():
            db.execute("INSERT INTO menstrual_records (user_id,start_date,end_date,flow,notes) VALUES (?,?,?,?,?)",
                       (g.user["id"], s.isoformat(), (s + timedelta(days=4)).isoformat(), flows[i % 3], "Sample data"))
    db.commit()
    flash("Sample cycles added.", "success")
    return redirect(url_for("calendar"))


@app.route("/questionnaire", methods=["GET", "POST"])
@consent_required
def questionnaire():
    prev = latest("symptoms", g.user["id"])
    answers = {k: (prev[k] if prev else None) for k in SYMPTOM_TEXT}
    if request.method == "POST":
        answers = {k: request.form.get(k) for k in SYMPTOM_TEXT}
        if any(v not in VALID_ANSWERS for v in answers.values()):
            flash("Please answer every question before submitting.", "danger")
        else:
            db = get_db()
            cols = ", ".join(answers)
            db.execute(f"INSERT INTO symptoms (user_id, {cols}) VALUES (?, {','.join('?' * len(answers))})",
                       (g.user["id"], *answers.values()))
            db.commit()
            run_assessment(g.user["id"])
            return redirect(url_for("result"))
    return render_template("questionnaire.html", questions=QUESTIONS, answers=answers)


@app.route("/assessment", methods=["GET", "POST"])
@consent_required
def assessment():
    """Recalculate the score (e.g. after adding new periods)."""
    if request.method == "POST":
        if run_assessment(g.user["id"]):
            return redirect(url_for("result"))
    flash("Please complete the symptom questionnaire first.", "warning")
    return redirect(url_for("questionnaire"))


@app.route("/result")
@consent_required
def result():
    data = report_data(g.user["id"])
    if data is None:
        flash("Complete the questionnaire to see your result.", "warning")
        return redirect(url_for("questionnaire"))
    return render_template("result.html", d=data)


@app.route("/report")
@consent_required
def report():
    data = report_data(g.user["id"])
    if data is None:
        flash("Complete the questionnaire to generate a report.", "warning")
        return redirect(url_for("questionnaire"))
    return render_template("report.html", d=data)


@app.route("/report/pdf")
@consent_required
def report_pdf():
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
    d = report_data(g.user["id"])
    if d is None:
        return redirect(url_for("questionnaire"))
    st, c, a = getSampleStyleSheet(), d["cycles"], d["assessment"]
    story = []

    def h(text): story.extend([Spacer(1, 10), Paragraph(escape(text), st["Heading2"])])
    def p(text): story.append(Paragraph(escape(str(text)), st["BodyText"]))

    story.append(Paragraph("Doctor Report - Early-Risk Screening Summary", st["Title"]))
    h("User Information")
    p(f"Name: {g.user['name']}"); p(f"Age: {g.user['age']}"); p(f"Assessment date: {d['date']}")
    h("Menstrual Information")
    p(f"Last period: {c['last_period'] or 'n/a'}")
    p(f"Average cycle length: {c['avg'] or 'n/a'} days")
    p(f"Recorded cycle lengths (days): {', '.join(map(str, c['lengths'])) or 'n/a'}")
    for msg in c["messages"]: p(f"- {msg}")
    h("Questionnaire Summary")
    if d["selected"]:
        for text, ans in d["selected"]: p(f"- {text} ({ans})")
    else:
        p("No symptoms reported.")
    h("Screening Result")
    p(f"Early-Risk Indicator Score: {a['score']}/100"); p(f"Category: {a['category']}")
    p("Main contributing factors: " + (", ".join(f["label"] for f in d["on"]) or "none"))
    h("Important Disclaimer")
    p(REPORT_DISCLAIMER)
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4).build(story)
    buf.seek(0)
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name="doctor_report.pdf")


# ---------- privacy ----------
@app.route("/privacy")
@consent_required
def privacy():
    uid, db = g.user["id"], get_db()
    return render_template("privacy.html",
                           records=fetch_records(uid), symptoms=latest("symptoms", uid),
                           assessments=db.execute("SELECT * FROM assessments WHERE user_id=? ORDER BY id DESC",
                                                  (uid,)).fetchall())


@app.route("/delete-health-data", methods=["POST"])
@consent_required
def delete_health_data():
    db = get_db()
    for table in ("menstrual_records", "symptoms", "assessments"):
        db.execute(f"DELETE FROM {table} WHERE user_id = ?", (g.user["id"],))
    db.commit()
    flash("All your health data has been deleted. Reports are generated on demand, so none are stored.", "success")
    return redirect(url_for("privacy"))


@app.route("/delete-account", methods=["POST"])
@login_required
def delete_account():
    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (g.user["id"],))  # cascades to all health tables
    db.commit()
    session.clear()
    flash("Your account and all associated data were deleted.", "info")
    return redirect(url_for("register"))


init_db()

if __name__ == "__main__":
    app.run(debug=True)
